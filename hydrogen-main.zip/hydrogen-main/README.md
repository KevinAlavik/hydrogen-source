# Hydrogen-v4
### What is Hydrogen-v4
Hydrogen-v4 is hydrogen but better, no but for real Hydrogen-v4 is the new version. v4 is fully automated using the Starfiles API
### Functions
With v4 you can get over 800 apps and every app will be signed when you download them!
### Revokes?
v4 Have revokes like all the other stores, but we have a team that scans the internet for certificates and when the find one they will upload it to a private starfiles folder so we can use the API to get the cert files and sign the apps right when you press **GET**!
### Price
Normal: Free
### Developers
Panguin: Owner

Kevin Alavik: Founder

Parsa Yazdani: Owner of Starfiles/Starfiles API
### Tools we use
We use: Starfiles API, JavaScript, HTML, CSS

### URLs
[Hydrogen-v4](https://kevinalavik.github.io/hydrogen)

[Starfiles](https://starfiles.co)

**Copyright Hydrogen © 2022**
