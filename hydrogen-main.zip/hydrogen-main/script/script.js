function v4(signed) {
    if (signed === "yes") {
        window.open('https://panguin6010.github.io/hydrogen/iOS/v4.mobileconfig', '_parent')
    } if (signed === "no") {
        window.alert('Sorry we are not signed, please try again later!')
    } if (signed === "broken") {
        window.alert("The webclips dont work properly. You will be redirected to the store page")
        window.open("/hydrogen/v4.html", "_parent")
    } if (signed ===  "revoked") {
        window.alert("We are revoked, please try again later!\n(revoked means that you cannot install any of the applications)")
    }
}
