var p12 = "40a5a4bd52da"
var mobileprovision = "13ff1f3e84ec"
var password = "123456"

var appLimit = 200

const params = new Proxy(new URLSearchParams(window.location.search), {
  get: (searchParams, prop) => searchParams.get(prop),
});
// Get the value of "some_key" in eg "https://example.com/?some_key=some_value"
let customAppLimit = params.limit; // "some_value"


if (customAppLimit > appLimit) {
  var newAppLimit = customAppLimit
} else {
  var newAppLimit = appLimit
}


const req = new XMLHttpRequest();
req.responseType = "json";


req.open(
  "GET",
  
  "https://api.starfiles.co/2.0/files?public&extension=ipa&collapse=true&group=hash&sort=trending&limit=" + newAppLimit
);



req.send();

req.onreadystatechange = () => {
  onLoad();
};


function onLoad() {

  var appData = req.response;

  for (var i = 0; i < appData.length; i++) {

    var appTitle = appData[i].package_name == "" || appData[i].package_name === null ? appData[i].name : appData[i].package_name;

    var appsDiv = document.createElement("div")
    appsDiv.classList.add("apps")
    var appDiv = document.createElement("div");
    appDiv.classList.add("app");
    var appName = document.createElement("label");
    var appInstall = document.createElement("a");
    appInstall.classList.add("get")
    var appInstallText = document.createTextNode("GET")
     appInstall.href = "https://sign.starfiles.co/?ipa=" + appData[i].id + "&p12=" + p12 + "&mobileprovision=" + mobileprovision + "&password=" + password + "&redirect=true"
    
     //appInstall.href = "console.log('We are revoked\nbrb')"
  
    var appIcon = document.createElement("img")
    appIcon.src = "https://api.starfiles.co/file/icon/" + appData[i].id;
    appIcon.classList.add("app-icon")
    appIcon.setAttribute("loading", "lazy")

    var appNameText = document.createTextNode(appNameChange(appTitle));
    appName.appendChild(appNameText);
    appInstall.appendChild(appInstallText)
    document.body.appendChild(appDiv);

    appDiv.appendChild(appIcon);
    appDiv.appendChild(appName);
    appDiv.appendChild(appInstall);

    //console.log(appData[i])
  }
};

function appNameChange(at) {
  var appNameFinal = at
    .replace("?", "")
    .replace(".ipa", "")
    .replace(" - cokernutX", "")
    .replace("signed", "")
    .replace("_", " ")
    .replace("-", " ")
    .replace("_", "")
    .replace("_strejda603", "")
    .replace("dev.3[tg@iapps ipa]", "")
    .replace(" iOSGods.com", "")
    .replace("Lyrication Spotilife 1.6", "")
  
  return appNameFinal
}


